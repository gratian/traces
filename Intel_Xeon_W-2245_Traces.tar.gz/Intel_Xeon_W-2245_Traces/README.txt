Reproducing case for latency spike on Intel(R) Xeon(R) W-2245 CPU @ 3.90GHz
===========================================================================

Test parameters
----------------

  * Intel(R) Xeon(R) W-2245 CPU @ 3.90GHz (cpu family: 6, model: 85, stepping:7,
    microcode: 0x5002f01)

  * BIOS tuned for best RT performance: disabled C-states and P-states, turboboost etc.

  * kernel: 5.10.56-rt48 #1 SMP PREEMPT_RT Thu Aug 12 14:52:31 CDT 2021 x86_64
    x86_64 x86_64 GNU/Linux

  * kernel configured with full preemption and dynamic ticks (PREEMPT_RT, NO_HZ_FULL).

  * kernel parameters used to lower the latency and isolate the last CPU in the
    system for the polling test:

    rcu_nocbs=all mitigations=off mce=ignore_ce intel_pstate=disable
    intel_idle.max_cstate=0 processor.max_cstate=0 nosoftlockup
    audit=0 idle=poll tsc=nowatchdog isolcpus=7 nohz_full=7

  * kernel source:
    git://git.kernel.org/pub/scm/linux/kernel/git/rt/linux-stable-rt.git
    (branch: v5.10-rt)

  * NI built Yocto rootfs.

  * 'clock_gettime-test' polling test using clock_gettime() in a loop on an
    isolated CPU (last CPU on the system).

  * 'cpu-no-idle' load test on all other CPUs writing continuously to
    /dev/zero. Alternate loads like hackbench (rt-tests package) also work
    really well.

  * test requires root access.

Run test
--------

Start load with:

# ./cpu-no-idle &                       
[1] 20442                               
Found 8 CPUs. Starting 7 busy threads...
starting thread on cpu: 0               
starting thread on cpu: 1               
starting thread on cpu: 2               
starting thread on cpu: 3               
starting thread on cpu: 4               
starting thread on cpu: 5               
starting thread on cpu: 6

Run test with event ftracing enabled:

# ./clock_gettime-test --max=20000 --priority=3 --duration=12h --tracing > hist.txt

To extract the trace if latency threshold exceeded use:

# trace-cmd extract

Files
------
.
├── bin
│   ├── clock_gettime-test			- polling loop test, see: 'clock_gettime-test --help'                   
│   └── cpu-no-idle				- load; spawns threads writing to '/dev/zero' to keep CPUs from going id
├── conf					                                                                        
│   └── config.gz				- 5.10 kernel .config used
├── logs					                                                                        
│   ├── cpuinfo.log				- /proc/cpuinfo contents
│   ├── dmesg-4.14.244-rt121.log		- 4.14 kernel log
│   ├── dmesg-5.10.56-rt48.log			- 5.10 kernel log
│   ├── kernel_cmdline.log			- full kernel command line
│   ├── lsmod.log				- loaded kernel modules                                                
│   ├── meminfo.log				- /proc/meminfo contents                                                
│   └── test.log				- test command line used                                                                        
├── README.txt					- this file
├── src						
│   ├── clock_gettime-test.c			- source for clock_gettime() based polling loop test                                                                        
│   └── cpu-no-idle.c				- source for test load
└── traces
    ├── latency-4.14.244-rt121_histogram_ns.txt	- saved latency histogram data from one of the test runs above 20uS threshold (4.14 kernel)
    ├── latency-5.10.56-rt48_histogram_ns.txt	- saved latency histogram data from one of the test runs above 20uS threshold (5.10 kernel)
    ├── trace-4.14.244-rt121_20uS_threshold.dat	- trace file from 4.14-rt kernel run showing the CPUs stalling (load in kernelshark)
    ├── trace-4.14.244-rt121_20uS_threshold.png	- kernelshark screenshot of the 4.14-rt trace above showing the >20uS CPUs stall
    ├── trace-5.10.56-rt48_20uS_threshold.dat	- trace file from 5.10-rt kernel run showing the CPUs stalling (load in kernelshark)
    └── trace-5.10.56-rt48_20uS_threshold.png	- kernelshark screenshot of the 5.10-rt trace above showing the >20uS CPUs stall
