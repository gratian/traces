/**
 * Quick & dirty busy looping load used to keep CPUs from going idle.
 *
 * Uses writes to /dev/zero to create the load (and observable trace events
 * since system calls show up in an ftrace event trace).
 *
 * Build with:
 *     gcc -o cpu-no-idle cpu-no-idle.c -lpthread
 */

#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/sysinfo.h>
#include <fcntl.h>

static void* thread_fn(void *param)
{
	volatile unsigned int tmp;
	cpu_set_t mask;
	long cpu = (long)param;
	int h;

	printf("starting thread on cpu: %d\n", cpu);

	h = open("/dev/zero", O_RDWR);
	if (!h)
		perror("failed to open /dev/zero");

	CPU_ZERO(&mask);
	CPU_SET(cpu, &mask);
	if (sched_setaffinity(0, sizeof(mask), &mask) < 0)
		printf("[warn] failed to set the affinity to CPU %d\n", cpu);

	while(1) {
		tmp += 1;
		if (h)
			write(h, (const void*)&tmp, sizeof(tmp));
	}
}

int main()
{
	pthread_t *threads;
	long nthreads;
	long ncpus = get_nprocs();
	char thread_name[16];
	long i;

	signal(SIGHUP, SIG_IGN);

	if (ncpus <= 0) {
		printf("[error] get_nprocs failed with ret=%d\n", ncpus);
		exit(EXIT_FAILURE);
	}
	nthreads = ncpus - 1;

	printf("Found %d CPUs. Starting %d busy threads...\n", ncpus, nthreads);

	threads = (pthread_t*)malloc(nthreads * sizeof(pthread_t));
	if (!threads) {
		printf("[error] failed to allocate memory for pthread_t array\n");
		exit(EXIT_FAILURE);
	}

	for (i = 0; i < nthreads; i++) {
		if (pthread_create(&threads[i], NULL, thread_fn, (void*)i) != 0) {
			printf("[error] failed to create thread %d\n", i);
			exit(EXIT_FAILURE);
		}
		snprintf(thread_name, 16, "busy_%d", i);
		pthread_setname_np(threads[i], thread_name);
	}

	for (i = 0; i < nthreads; i++)
		pthread_join(threads[i], NULL);

	return EXIT_SUCCESS;
}
