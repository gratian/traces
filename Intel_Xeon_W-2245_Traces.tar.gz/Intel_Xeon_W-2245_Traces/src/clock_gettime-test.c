/**
 * clock_gettime() based polling loop test.
 *
 * Build with:
 *     gcc -O2 -o clock_gettime-test clock_gettime-test.c
 */
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <err.h>
#include <errno.h>
#include <sched.h>
#include <time.h>
#include <limits.h>
#include <sys/mman.h>
#include <sys/sysinfo.h>
#include <signal.h>
#include <getopt.h>
#include <ctype.h>
#include <dirent.h> 

#define MAX_LATENCY	10000000L
#define NSEC_PER_SEC	1000000000ULL
#define WARMUP_SEC	60

struct histogram {
	uint64_t *data;
	uint64_t size;
	uint64_t max;
};

struct test_options {
	uint64_t max_latency;
	uint64_t duration;
	int priority;
	long cpu;
	bool tracing;
};

static bool g_stop;

enum {
        OPT_HELP = 1,
        OPT_MAX_LATENCY,
        OPT_DURATION,
        OPT_PRIORITY,
        OPT_TRACING,
};

static struct option opt_long[] = {
        {"max", required_argument, NULL, OPT_MAX_LATENCY},
        {"duration", optional_argument, NULL, OPT_DURATION},
        {"priority", optional_argument, NULL, OPT_PRIORITY},
        {"tracing", optional_argument, NULL, OPT_TRACING},
        {"help", no_argument, NULL, OPT_HELP},
        {NULL, 0, NULL, 0}
};

const char *opt_short = "m:d:p:th";

static void usage(char* comm)
{
        printf("Usage:\n"
               "%s <options>\n"
	       "\t-m <nS> --max=<nS>\t\tMax latency threshold in nanoseconds (10ms max)\n"
	       "\t-d <time> --duration=<time>\tTest duration in seconds\n"
	       "\t\t\t\t\t(m, h, d modifiers can be used to specify minutes, hours, or days)\n"
	       "\t-p <prio> --priority=<prio>\tRT_FIFO priority\n"
	       "\t-t --tracing\t\t\tEnable event (f)tracing\n"
               "\t-h --help\t\t\tDisplay this help\n",
               comm);
}

static int parse_options(int argc, char *argv[], struct test_options* const opt)
{
        int c;
        int index = 0;
	char *endptr = NULL;

	if (!opt || argc < 2)
		goto err_exit;

        while ((c = getopt_long(argc, argv, opt_short, opt_long, &index)) >= 0) {
                switch (c) {
			case 'm':
			case OPT_MAX_LATENCY:
				opt->max_latency = strtoll(optarg, &endptr, 10);
				if (opt->max_latency > MAX_LATENCY) {
					fprintf(stderr,
						"error: maximum latency %d, exceeds %lu(ns) upper limit\n",
						opt->max_latency,
						MAX_LATENCY);
					goto err_exit;
				}
				break;
                        case 'd':
                        case OPT_DURATION:
                                opt->duration = strtoll(optarg, &endptr, 10);
				if (optarg == endptr)
					goto err_exit;
				switch (tolower(*endptr)) {
					case 'm':
						/* minutes */
						opt->duration *= 60;
						break;
					case 'h':
						/* hours */
						opt->duration *= 60 * 60;
						break;
					case 'd':
						opt->duration *= 60 * 60 * 24;
						/* days */
						break;
					case 0:
						/* default to seconds */
						break;
					default:
						fprintf(stderr,
							"error: unrecognized modifier '%c' used for specifying the test duration\n",
							*endptr);
						goto err_exit;
				}
                                break;
			case 'p':
			case OPT_PRIORITY:
				opt->priority = strtoll(optarg, &endptr, 10);
				if (opt->priority < sched_get_priority_min(SCHED_FIFO)) {
					fprintf(stderr,
						"error: %d priority is less than %d SCHED_FIFO minimum priority\n",
						opt->priority, sched_get_priority_min(SCHED_FIFO));
					goto err_exit;
				}
				if (opt->priority > sched_get_priority_max(SCHED_FIFO)) {
					fprintf(stderr,
						"error: %d priority is more than %d SCHED_FIFO maximum priority\n",
						opt->priority, sched_get_priority_max(SCHED_FIFO));
					goto err_exit;
				}
				break;
			case 't':
			case OPT_TRACING:
				opt->tracing = true;
				break;
                        case '?':
                        case 'h':
                        case OPT_HELP:
				goto err_exit;
                }
        }
	return 0;

  err_exit:
	usage(argv[0]);
	return -1;
}

static int write_text_file(const char *path, const char* text)
{
	FILE *f = fopen(path, "w");
	if (!f)
		return -1;
	if (fprintf(f, "%s\n", text) < 0)
		return -1;
	fclose(f);
	return 0;
}

#define TRACE_PATH(NAME)	"/sys/kernel/debug/tracing/"#NAME
#define TRACE_ON()		(write_text_file(TRACE_PATH(tracing_on), "1"))
#define TRACE_OFF()		(write_text_file(TRACE_PATH(tracing_on), "0"))
#define TRACE_CLEAR()		(write_text_file(TRACE_PATH(trace), NULL))
#define TRACE_EVENTS_ON()	(write_text_file(TRACE_PATH(events/enable), "1"))
#define TRACE_MARKER(MARK)	(write_text_file(TRACE_PATH(trace_marker), MARK))

static void tsnorm(struct timespec *ts)
{
	while (ts->tv_nsec >= NSEC_PER_SEC) {
		ts->tv_nsec -= NSEC_PER_SEC;
		ts->tv_sec++;
	}
}

static inline uint64_t tsdiff(const struct timespec* const start, const struct timespec* const end)
{
	uint64_t t1 = (uint64_t)(start->tv_sec) * NSEC_PER_SEC +
		start->tv_nsec;
	uint64_t t2 = (uint64_t)(end->tv_sec) * NSEC_PER_SEC +
		end->tv_nsec;

	return t2 - t1;
}

static void clock_gettime_test(const struct test_options* const opt, struct histogram* const h, bool warmup)
{
	char mark[PATH_MAX];
	struct timespec prev_ts;
	struct timespec ts;
	time_t end_sec;
	uint64_t dt;

	if (!opt || !h)
		return;

	clock_gettime(CLOCK_MONOTONIC, &prev_ts);
	end_sec = prev_ts.tv_sec;
	end_sec += (warmup) ? WARMUP_SEC : opt->duration;

	while (prev_ts.tv_sec < end_sec && !g_stop) {
		clock_gettime(CLOCK_MONOTONIC, &ts);

		dt = tsdiff(&prev_ts, &ts);
		if (dt > h->max)
			h->max = dt;
		if (dt >= opt->max_latency && !warmup) {
			snprintf(mark, PATH_MAX, "# fail: latency %llu(ns), above %llu(ns) threshold",
				 dt, opt->max_latency);
			if (opt->tracing) {
				TRACE_MARKER(mark);
				TRACE_OFF();
			}
			printf("%s", mark);
			break;
		}
		if (dt < h->size)
			h->data[dt]++;
		prev_ts = ts;
	}

	if (warmup) {
		h->max = 0;
		memset(h->data, 0, h->size);
	}
}

static void print_banner(const struct test_options* const opt)
{
	printf("# clock_gettime() polling loop test\n");
	printf("# running test for %lu seconds (+%lu seconds warm-up), at RT_FIFO priority %d\n",
	       opt->duration,
	       WARMUP_SEC,
	       opt->priority);
	printf("# max latency threshold: %lu nanoseconds\n", opt->max_latency);
	printf("# tracing: %s\n", (opt->tracing) ? "on":"off");
	printf("# test CPU: %d\n", opt->cpu);
	printf("#\n");
}

static void print_hist_data(const struct histogram* const h)
{
	uint64_t i;

	printf("# bin count\n");
	for (i = 0; i <= h->max && i < h->size; i++)
		printf("%05llu %llu\n", i, h->data[i]);
}

static void sigint_handler(int sig)
{
	g_stop = true;
}

static int set_fifo_priority(int prio)
{
	struct sched_param schedp;

	memset(&schedp, 0, sizeof(schedp));
	schedp.sched_priority = prio;
	return sched_setscheduler(0, SCHED_FIFO, &schedp);
}

static int set_cpu_affinity(int cpu)
{
	cpu_set_t mask;

	CPU_ZERO(&mask);
	CPU_SET(cpu, &mask);
	return sched_setaffinity(0, sizeof(mask), &mask);
}

static void set_cpu_mask(char* path, void* data)
{
	unsigned long mask = (long)data;
	FILE *f;

	f = fopen(path, "w");
	if (f) {
		fprintf(f, "%u", mask);
		fclose(f);
	}
}

static void find(char* path, char* name, void (*fn)(char*, void*), void* data)
{
	DIR *d;
	struct dirent *dir;

	if (!path || !name)
		return;

	d = opendir(path);
	if (d) {
		while ((dir = readdir(d)) != NULL) {
			char* fullpath;
			if (!strncmp(dir->d_name, ".", 1) ||
			    !strncmp(dir->d_name, "..", 2))
				continue;

			fullpath = malloc(strlen(path) +
					  strlen(dir->d_name) + 2);
			if (!fullpath)
				err(1, "Failed to allocate memory for path");
			sprintf(fullpath, "%s/%s", path, dir->d_name);

			if (!strcmp(dir->d_name, name))
				(*fn)(fullpath, data);

			if (dir->d_type == DT_DIR)
				find(fullpath, name, fn, data);
			free(fullpath);
		}
		closedir(d);
	}
}

static int flush_disk_io()
{
	int ret;

	ret = write_text_file("/proc/sys/vm/drop_caches", "3");
	sync();
	return ret;
}

static int set_vm_stat_interval()
{
	return write_text_file("/proc/sys/vm/stat_interval", "600");
}

static int disable_rt_throttling()
{
	return write_text_file("/proc/sys/kernel/sched_rt_runtime_us", "-1");
}

static void setup(const struct test_options* const opt, struct histogram *h)
{
	const unsigned long cpu0_mask = 1;

        signal(SIGINT, sigint_handler);
        signal(SIGHUP, SIG_IGN);

	h->max = 0;
	h->size = opt->max_latency;
	h->data = (uint64_t*)calloc(h->size, sizeof(uint64_t));
	if (h->data == NULL)
		err(1, "Failed to allocate memory for histogram data");

	if (opt->tracing) {
		TRACE_OFF();
		TRACE_CLEAR();
		TRACE_EVENTS_ON();
		TRACE_ON();
	} else {
		TRACE_OFF();
	}

	if (mlockall(MCL_CURRENT | MCL_FUTURE) < 0)
		err(1, "Failed to mlockall memory");

	if (set_fifo_priority(opt->priority) < 0)
		err(1, "Failed to set the test scheduling priority");

	if (set_cpu_affinity(opt->cpu) < 0)
		err(1, "Failed to set the CPU affinity");

	if (set_vm_stat_interval() < 0)
		err(1, "Failed to set vm.stat_interval");

	if (disable_rt_throttling() < 0)
		err(1, "Failed to disable RT scheduler's throttling");

	/* move workqueue threads to CPU 0 */
	find("/sys/devices/virtual/workqueue", "cpumask", set_cpu_mask, (void*)cpu0_mask);

	/* move irq threads to CPU 0 */
	find("/proc/irq", "smp_affinity", set_cpu_mask, (void*)cpu0_mask);

	if (flush_disk_io() < 0)
		err(1, "Failed to flush disk caches");
}

int main(int argc, char* argv[])
{
	struct histogram hist;
	uint64_t dt;
	long ncpus = get_nprocs();
	struct test_options opt = {
		.max_latency = 20000,
		.duration = 60,
		.priority = 2,
		.tracing = false,
		.cpu = ncpus - 1,
	};

	if (parse_options(argc, argv, &opt) < 0) {
		fprintf(stderr, "error: failed to parse arguments\n");
		return EXIT_FAILURE;
	}
	print_banner(&opt);
	setup(&opt, &hist);

	/* warm-up */
	clock_gettime_test(&opt, &hist, true);

	/* run test */
	clock_gettime_test(&opt, &hist, false);

	print_hist_data(&hist);

	return EXIT_SUCCESS;
}
